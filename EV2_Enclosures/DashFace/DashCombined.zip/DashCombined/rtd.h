/*
	rtd.h 
	Globals and helper functions for the RTD / throttle gate system 
	Assumes presence of a uint8_t shutdownState which represents the state of the SDC
*/
#ifndef RTD
#define RTD
#include "defines.h"
//#include "rtd"
bool isRTD = 0;

//Helper function prototypes
bool checkRTD();
void enableRTD(bool*);
void disableRTD(bool*);


#endif